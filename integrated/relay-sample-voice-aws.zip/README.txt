Read docs/TEAM_HANDOFF.md. No credentials included. Installation does not schedule calls or enable payment. Source is separately available in relay-source.zip.
